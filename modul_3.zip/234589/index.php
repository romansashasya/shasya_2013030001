<?php

	header("Location: mhs/");

?>