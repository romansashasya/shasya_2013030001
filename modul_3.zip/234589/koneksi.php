<?php
	$servername = 'localhost';
	$username = 'root';
	$password ='';
	$db ='ppwpwpw';
	$conn = new mysqli($servername,$username,$password,$db);
 ?>